# cobblemon-bedrock-runtime

Platform-neutral Bedrock geometry and animation evaluation using Cobblemon's ModelPart coordinate mapping. The package exposes compiled static geometry, exact per-frame world transforms, and the legacy flattened mesh interface used by Helios.

The package is UNLICENSED.
